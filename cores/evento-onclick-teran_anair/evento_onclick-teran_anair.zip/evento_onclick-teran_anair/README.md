# Evento onclick

Asignación evento onclick.

![Evento onclick](/resources/resultado.png)

## Tecnologías utilizadas

- HTML
- CSS
- JavaScript
